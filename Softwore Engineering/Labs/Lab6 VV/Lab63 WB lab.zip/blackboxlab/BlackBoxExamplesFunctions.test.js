const BlackBoxExamplesFunctions = require('./BlackBoxExamplesFunctions');

// describe, test, expect, toBe // learn online the syntax to write jtests 
