1. Run "npm init" and fill the configuration parameters: 
	- package name: the folder that contains the project
	- version: leave the default choice
	- description: leave empty
	- entry point: main.js
	- test command: leave empty
	- leave all the remaining choices as the defaut ones
	
2. Open the package.json file and add or update this section 
	"scripts": {
	  "test": "jest"
	 } 

3. Write your tests inside BlackBoxExamplesFunctions.test.js

4. Run "npm install --save-dev jest"
5. Run "npm test" 
