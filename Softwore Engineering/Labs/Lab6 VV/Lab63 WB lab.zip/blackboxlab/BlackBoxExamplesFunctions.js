class BlackBoxExamplesFunctions{

    static acceptableToEat( carb, protein, fat){
        
        if(carb < 0 || protein < 0 || fat <0) return false;
        
        if (4*carb + 4*protein + 9*fat < 1000 && ((carb + protein) / fat > 0.5)) return true;		
        
        else return false;
    }

    static computeFee(duration, minRate, minRate2) {
		
		if (duration < 0 || minRate < 0 || minRate2 < 0) return -1.0;

		if (duration < 30) return 0.0;
		
		if (duration >= 30 && duration < 90) return minRate*(duration - 30);
		
		else return 60*minRate + (duration-90)*minRate2;
		
	}

    static computeFee(basePrice, n_passengers, n_over18, n_under15) {
		
		if (basePrice < 0 || n_passengers < 0 || n_over18 < 0 || n_under15 < 0) return -1.0;
		if (n_over18 + n_under15 > n_passengers) return -1.0;
		
		
		if (n_passengers >=2 && n_passengers <=5 && n_over18>0) {
			return basePrice*(n_passengers -n_under15);
		}
		
		else {
			return basePrice*n_passengers;
		}
	}
}

module.exports = BlackBoxExamplesFunctions