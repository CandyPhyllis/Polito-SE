const BlackBoxExamplesFunctions = require("./BlackBoxExamplesFunctions");

console.log(BlackBoxExamplesFunctions.acceptableToEat(5,5,5));
console.log(BlackBoxExamplesFunctions.computeFee(55,10,20));
console.log(BlackBoxExamplesFunctions.computeFee(20,3,0,0));